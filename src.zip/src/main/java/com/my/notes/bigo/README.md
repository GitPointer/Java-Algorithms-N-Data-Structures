# What is Big-O notation
### Big-O is a way to describe how long an algorithm or a program take to execute. In a nutshell It describe the performance or complexity of an algorithm/program.

#### * It's like math calculation but instead of focusing on exact result it gives an estimate and focus on what's basically happening.

#### * In computer Science big O notation is used to describe the execution time or space required for an algorithm/program with diffrent input data set. It gives estimate about performance when input gets arbitrarily large.

Either the time of Study or after starting enginnering job Big-O was _a tough row to hoe_ for me.